***************************
JEDI KNIGHT II MODIFICATION
***************************

Title : <|FeaR|> Clan Arena
Version: 2.0 (Final)
File Type: Jedi Knight II: FFA / TFFA Map
Author : Thomas Knight
E-Mail : thomasknight_1999@hotmail.com
Website : http://www.rpgsprites.com http://www.usao.edu/~stuknightt

File Name : ffa_fear_arena.zip
File Size : 730 KB
Date Released : 03/09/2003

Description: This arena was created for my clan. It wasn't really anything that was planned though. One day, I was browsing some random forum somewhere. Someone suggested a mapper make a roman-collesium like map, with tunnels beneath it. And so, the <|FeaR|> Clan Arena was born. It consists of 1) an above ground collesium with a floating duel platform and VIP seating, 2) a second level with 3 duel rooms, and 3) a third level with a floating platform above a bottomless pit.

Updated: I edited the lighting above the outdoor arena, and the platform above the pit. They were both a little too bright. I also added... a little secret area. Have fun looking for it. Muuaahahahah.... ahem, um, sorry. *cough* seating *cough* box *cough* :)

Comments: This is my first map for Jedi Knight IIJK2 map. I welcome tips, hints, etc....

Thanks: I want to send thanks out to my friends Jake and Garrett for their input and ideas. A big thank you out to <|FeaR|>Storm for helping me with stuff whenever I needed it. And a HUGE thank you out to RichDiesel, I know you're not really on the scene anymore, but you're still helping people.

Installation: Extract the ffa_fear_arena.pk3 file into your GAMEDIR/GameData/base directory.


THIS MODIFICATION IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN, OR
LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS.